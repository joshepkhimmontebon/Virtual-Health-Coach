<?php
// Include config.php
@include 'config.php';

session_start();
if (!isset($_SESSION['doctor_name'])) {
    header('location:login_form.php');
    exit();
}

// Check if the ID is provided
if (!isset($_GET['id'])) {
    header('location:sc_doc.php'); // Redirect if ID is not provided
    exit();
}

// Get the ID from the URL
$id = mysqli_real_escape_string($conn, $_GET['id']);

// Query to fetch specific user's details
$sql = "SELECT * FROM user_form WHERE User_ID = '$id'";
$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
    echo "Error: " . mysqli_error($conn);
    exit();
}

$row = mysqli_fetch_assoc($result); // Fetch the user details
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="scd.css">
    <title>User Details</title>
</head>
<body>
    <div class="hero" style="background-image: url('bb.jpg'); background-repeat: no-repeat; background-size: cover; ">
        <nav>
            <a href="#" class="logo">Healthcare at Your Fingertips</a>
            <ul>
                <li><a href="doctor_page.php">About</a></li>
                <li><a href="sc_doc.php">Symptom Checker</a></li>
                <li><a href="he_doc.php">Healthcare Education</a></li>
                <li><a href="f_doc.php">FAQ</a></li>
            </ul>
            <img src="9.png" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="5.png">
                        <h3><span><?php echo $_SESSION['doctor_name'] ?></span></h3>
                    </div>
                    <hr>
                    <a href="formuser.php" class="sub-menu-link">
                        <img src="10.png">
                        <p>Doctor Details</p>
                        <span>></span>
                    </a>

                        <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                            <img src="3.png">
                            <p>Logout</p>
                            <span>></span>
                        </a>
                </div>
            </div>
        </nav>

        <div class="contain" style="max-width: 1500px; margin: 0 auto; text-align: center; font-size: 50px; background-color: #ffffffec; padding: 20px; border-radius: 40px;">
            <h2>User Details</h2>
            <?php if ($row): ?>
                <div>
                    <p>Username: <?php echo $row['username']; ?></p>
                    <p>Email: <?php echo $row['email']; ?></p>
                    <p>Age: <?php echo $row['age']; ?></p>
                    <p>Sex: <?php echo $row['sex']; ?></p>
                    <p>Contact: <?php echo $row['contact']; ?></p>
                    <p>Address: <?php echo $row['address']; ?></p>
                </div>
            <?php else: ?>
                <p>No user found with the provided ID.</p>
            <?php endif; ?> <br><br>
            <a href="sc_doc.php" style="font-size: 30px">Go Back </a>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let subMenu = document.getElementById("subMenu");

            function toggleMenu() {
                subMenu.classList.toggle("open-menu");
            }

            // Add an event listener to the user-pic element to call the toggleMenu function when clicked
            document.querySelector('.user-pic').addEventListener('click', toggleMenu);

            // Add an event listener to the logout link to show a confirmation prompt
            document.getElementById('logoutLink').addEventListener('click', function(event) {
                if (!confirm("Are you sure you want to logout?")) {
                    event.preventDefault(); // Prevent default action if user cancels
                }
            });
        });
    </script>
</body>
</html>