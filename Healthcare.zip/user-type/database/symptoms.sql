-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2024 at 11:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `User_ID` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `symptom` varchar(255) NOT NULL,
  `duration` int(11) NOT NULL,
  `lifestyle` varchar(255) NOT NULL,
  `datesymp` date NOT NULL,
  `sub_num` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`User_ID`, `name`, `symptom`, `duration`, `lifestyle`, `datesymp`, `sub_num`) VALUES
(8, 'nins', 'ssss', 35, 'ssdd', '2024-05-11', 4),
(8, 'nins', 'asdf', 3, 'asdf', '2024-05-11', 5),
(9, 'kat', 'wer', 1, 'wers', '2024-05-11', 6),
(9, 'kat', 'cough', 40, 'awaw', '2024-05-11', 7),
(8, 'nins', 'wee', 9, 'sad', '2024-05-13', 8),
(8, 'nins', 'cough', 9, 'ambot', '2024-05-16', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`sub_num`),
  ADD KEY `User_ID` (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `sub_num` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
