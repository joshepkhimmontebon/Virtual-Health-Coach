-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2024 at 11:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `user_id` int(11) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `contact` varchar(1000) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`user_id`, `user_type`, `username`, `email`, `age`, `sex`, `contact`, `address`, `password`) VALUES
(1, 'user', 'Ericca', 'ericca@gmail.com', 25, 'female', '09055778594', 'manila', '$2y$10$sAS5F/vLQbYsR5/N./jKcOJPk/QIpNlAMssks/FDZW9fhnD92V5/e'),
(2, 'doctor', 'kaye', 'kaye@gmail.com', 21, 'female', '09363022377', 'tibanga', '$2y$10$q1.IFowYdqVYsxG/93rTfuhMFKS0QL.QI.eLYoyj6pGOZKFpCSytu'),
(3, 'user', 'nina', 'nina@gmail.com', 20, 'female', '09055763809', 'villaverde', '$2y$10$4H7seOJxtBHpecr4xjwjMOJQ2EHtJLS9zIwS9zh3ykQpmWTx17Coy'),
(4, 'user', 'joe', 'joe@123gmail.com', 12, 'female', '2147483647', 'iligan', '$2y$10$.hNKlIEleX9sTEgigTvWBeHGH1DthV2pfH/Nr7qPppHuFwBBocMIi'),
(8, 'user', 'nins', 'nins@gmail.com', 20, 'female', '09709180441', 'villaverde', '$2y$10$rK5MO5PB.lmlUPhgo9aAhOYqeIRXpGd7hL9j5Iv5xZk9xb6GiboFS'),
(9, 'user', 'kat', 'kat@1', 43, 'female', '09213123', 'asbdjashdja', '$2y$10$cIuScK8f0VmVHu.e09ErOe995piTu0NMxFzAP6FfstjugAKD.N1Vu'),
(10, 'user', 'asd', 'asd2ads@asd', 123, 'asd', '13', 'asdads', '$2y$10$/iImSR9Chl5vTYlXQrBimeg/A0kMbFgeMs4.i/oH1A/jyu1v0pG3e'),
(11, 'doctor', 'qu', 'qu@e', 12, 'female', '312', 'asdas', '$2y$10$QJXQY0VpJWcNgyZ5CB4gDuo0RU3bRnTjrC/9YHlzekUMYvRZloASa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
