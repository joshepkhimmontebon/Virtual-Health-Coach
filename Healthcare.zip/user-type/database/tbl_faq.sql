-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2024 at 11:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faq`
--

CREATE TABLE `tbl_faq` (
  `tbl_faq_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_faq`
--

INSERT INTO `tbl_faq` (`tbl_faq_id`, `question`, `answer`) VALUES
(23, 'What causes a cough?', 'A cough can be caused by various factors, including viral infections (such as the common cold or flu), bacterial infections, allergies, irritants (like smoke or pollution), or even certain medications.'),
(24, 'What are the symptoms of a cough?', 'Symptoms of a cough can include a sore throat, congestion, runny nose, chest discomfort, shortness of breath, and the production of mucus or phlegm.'),
(25, 'When should I see a doctor for a cough?', 'You should see a doctor if your cough persists for more than three weeks, is accompanied by high fever, severe chest pain, difficulty breathing, coughing up blood, or if you have a weakened immune system.'),
(26, 'What causes a fever?', 'A fever is often a sign that your body is fighting off an infection. It can be caused by various infections, including viral, bacterial, or fungal infections. It can also be a response to other medical conditions or environmental factors.'),
(27, 'What are the symptoms of a fever?', 'Symptoms of a fever can include a high body temperature (usually above 100.4°F or 38°C), chills, sweating, headache, muscle aches, fatigue, and loss of appetite.'),
(28, 'How can I treat a fever at home?', 'You can treat a fever at home by getting plenty of rest, staying hydrated, and taking over-the-counter fever-reducing medications such as acetaminophen (Tylenol) or ibuprofen (Advil, Motrin).'),
(29, 'What causes the common cold?', 'The common cold is caused by a viral infection, most commonly by rhinoviruses. Other viruses, such as coronaviruses and adenoviruses, can also cause colds.'),
(30, 'What are the symptoms of the common cold?', 'Symptoms of the common cold can include a runny or stuffy nose, sore throat, cough, sneezing, mild headache, mild body aches, and low-grade fever.'),
(31, 'How long does a cold usually last?', 'A cold typically lasts for about 7-10 days, though symptoms may persist for up to two weeks in some cases. It\'s essential to rest, stay hydrated, and practice good hygiene to help your body recover faster.'),
(32, 'How can I prevent the spread of colds and flu?', 'You can help prevent the spread of colds and flu by washing your hands frequently, avoiding close contact with sick individuals, covering your mouth and nose when coughing or sneezing, and staying home when you\'re sick.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_faq`
--
ALTER TABLE `tbl_faq`
  ADD PRIMARY KEY (`tbl_faq_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_faq`
--
ALTER TABLE `tbl_faq`
  MODIFY `tbl_faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
