<?php

$conn = mysqli_connect('localhost', 'root', '123ABC12', 'user_db') or die('connection failed');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    // Get the id value from the URL
    $id = $_GET['id'];

    // Delete the record with the given id from the 'symptoms' table
    mysqli_query($conn, "DELETE FROM `symptoms` WHERE sub_num='$id'");

    // Redirect back to the page where the table is displayed
    header('location: sc.php');
    exit(); // Ensure that no further code execution occurs after redirection
}
?>
