<?php
include ('conn.php');

if (isset($_GET['faq'])) {
    $faq = $_GET['faq'];

    try {

        $query = "DELETE FROM tbl_faq WHERE tbl_faq_id = '$faq'";

        $stmt = $conn->prepare($query);

        $query_execute = $stmt->execute();

        if ($query_execute) {
            echo "
                <script>
                    alert('FAQ deleted successfully!');
                    window.location.href = 'http://localhost/user-type/f_doc.php';
                </script>
            ";
        } else {
            echo "
                <script>
                    alert('Failed to delete faq!');
                    window.location.href = 'http://localhost/user-type/f_doc.php';
                </script>
            ";
        }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

?>