<?php
    @include 'config.php';
    session_start();
    if(!isset($_SESSION['user_name'])){
       header('location:login_form.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ USER</title>
    <link rel="stylesheet" href="merged.css">
    
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="hero">
        <nav>
            <a href="#" class="logo">Virtual Health Coach</a>
            <ul>
                <li><a href="user_page.php">About</a></li>
                <li><a href="sc.php">Symptom Checker</a></li>
                <li><a href="he.php">Healthcare Education</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="ca.php">Contact Us</a></li>
            </ul>
            <img src="6.png" class="user-pic" onclick="toggleMenu()">
            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="5.png">
                        <h3><span><?php echo $_SESSION['user_name'] ?></span></h3>
                    </div>
                    <hr>
                    <a href="formuser.php" class="sub-menu-link" onclick="toggleSubMenu()">
                        <img src="10.png">
                        <p>User Details</p>
                        <span>></span>
                    </a>
                    <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                        <img src="3.png">
                        <p>Logout</p>
                        <span>></span>
                    </a>
                </div>
            </div>
        </nav>
        
        <section>
            <div class="box">
                <img src="doc.jpg" alt="Image Description" class="faq-image">
                <div class="faq-content">
                    <h1 class="faq-header">Frequently Asked Questions</h1>
                    <div class="faqs">
                        <?php 
                            include("conn.php");
                            if(isset($_GET['faq'])) {
                                $deleteID = $_GET['faq'];
                                $stmt = $conn->prepare("DELETE FROM tbl_faq WHERE tbl_faq_id = :id");
                                $stmt->bindParam(':id', $deleteID);
                                $stmt->execute();
                                header("Location: f.php");
                                exit();
                            }
                            
                            $stmt = $conn->prepare("SELECT * FROM tbl_faq");
                            $stmt->execute();
                            $result = $stmt->fetchAll();
                            $maxID = count($result);
                            foreach($result as $index => $row) {
                                $faqID = $index + 1;
                                $question = $row["question"];
                                $answer = $row["answer"];
                        ?>
                        <div class="faqs">
                    <div class="wrapper">
                        <input type="checkbox" name="acc" id="acc<?= $index + 1 ?>" class="acc-checkbox">
                        <label for="acc<?= $index + 1 ?>">
                            <h2><?= $faqID ?></h2>
                            <h3><?= $question ?></h3>
                        </label>
                        <div class="content">
                            <p><?= $answer ?></p>
                        </div>
                    </div>
                        <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <script>
        function toggleMenu() {
            let subMenu = document.getElementById("subMenu");
            subMenu.classList.toggle("open-menu");
        }

        function toggleSubMenu() {
            let subMenu = document.getElementById("subMenu");
            subMenu.classList.toggle("open-menu");
        }

        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById('logoutLink').addEventListener('click', function(event) {
                if (!confirm("Are you sure you want to logout?")) {
                    event.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
