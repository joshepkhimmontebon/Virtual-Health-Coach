<?php
// Include config.php
@include 'config.php';

session_start();
if (!isset($_SESSION['doctor_name'])) {
    header('location:login_form.php');
}

// Check if the form is submitted for adding doctor's advice
if (isset($_POST['add'])) {
    // Escape user inputs for security
    $numberr = mysqli_real_escape_string($conn, $_POST['numberr']);
    $datee = mysqli_real_escape_string($conn, $_POST['datedoc']);
    $patient = mysqli_real_escape_string($conn, $_POST['patient']);
    $recom_med = mysqli_real_escape_string($conn, $_POST['recom_med']);
    $advice = mysqli_real_escape_string($conn, $_POST['advice']);

    // Attempt to insert data into the database
    $sql = "INSERT INTO `doctors_advice` (numberr, datedoc,  patient, recom_med, advice) 
    VALUES ('$numberr' , '$datee' , '$patient' , '$recom_med' ,  '$advice')";                   //use NOW() function

    if (mysqli_query($conn, $sql)) {
        echo "Records added successfully.";
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}

// Check if the form is submitted for searching symptoms
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']);
    $sql = "SELECT * FROM symptoms WHERE name LIKE '%$search%'";
    $symptom_result = $conn->query($sql);
} else {
    // Default query to display all symptoms
    $sql = "SELECT * FROM symptoms";
    $symptom_result = $conn->query($sql);
}

// Check if the form is submitted for searching doctor's advice
if (isset($_POST['searchh'])) {
    $searchh = mysqli_real_escape_string($conn, $_POST['searchh']);
    $sqlh = "SELECT * FROM doctors_advice WHERE patient LIKE '%$searchh%'";
    $advice_result = $conn->query($sqlh);
} else {
    // Default query to display all doctor's advice
    $sqlh = "SELECT * FROM doctors_advice";
    $advice_result = $conn->query($sqlh);
}
?>

<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Healthcare at Your Fingertips</title>
    <link href="al.css" rel="stylesheet" />
    <link href="style1.css" rel="stylesheet" />
    <!-- Font Awesome icons (free version) -->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap) -->
    <link href="css/styles.css" rel="stylesheet" />
    <title>Symptom Checker</title>
</head>

<body id="page-top">

    <div class="hero" style="background-image: url('aa.jpg'); background-repeat: no-repeat; background-size: cover; ">
    <nav>
        <a class="logo">Virtual Health Coach</a>
        <ul>
            <li><a href="doctor_page.php">About</a></li>
            <li><a href="sc_doc.php">Symptom Checker</a></li>
            <li><a href="he_doc.php">Healthcare Education</a></li>
            <li><a href="f_doc.php">FAQ</a></li>
        </ul>
        <img src="9.png" class="user-pic" onclick="toggleMenu()">
        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user-info">
                    <img src="ai.png" alt="User">
                    <h3><span><?php echo $_SESSION['doctor_name'] ?></span></h3>
                </div>
                <hr>
                <a href="formdoc.php" class="sub-menu-link">
                        <img src="10.png">
                        <p>Doctor Details</p>
                        <span>></span>
                    </a>

                        <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                            <img src="3.png">
                            <p>Logout</p>
                            <span>></span>
                        </a>
            </div>
        </div>
    </nav>
        <div class="form-container" style="margin-left: -800px;  " id="contain" >
            <link rel="stylesheet" href="co.css">
            <link rel="stylesheet" href="sc.css">
            <link rel="stylesheet" href="checker.css">

            <form action="" method="post" enctype="multipart/form-data" style="margin-top: 150px; background-color: #ffffffc0;">
                <h2>Fill Up Form</h2>
                <?php
                if (isset($message)) {
                    foreach ($message as $msg) {
                        echo '<div class="message">' . $msg . '</div>';
                    }
                }
                ?>
                <input type="text" name="numberr" placeholder="Enter Form Number" class="box" required>
                <input type="date" name="datedoc" placeholder="mm/dd/yyyy" class="box" required>
                <input type="text" name="patient" placeholder="Enter User's Name" class="box" required>
                <input type="text" name="recom_med" placeholder="Enter Medicine Recommendation" class="box" required>
                <input type="text" name="advice" placeholder="Enter Advice" class="box" required>
                <input type="submit" name="add" class="btn">
            </form>

            <div class="contain" style="margin-top: -850px; margin-left: 1600px; width: 30%; background-color: #ffffffc0; padding: 10px; border-radius: 20px;">
                <div class="search-container" >
                    <form action="" method="post" style= "background-color: #ffffffc0; padding: 5px; border-radius: 10px; width: 300px;" >
                        <input type="text" name="search" placeholder="Search Name..." id="searchInput">
                        <button type="submit" style="margin-bottom:100px; ">Search</button>
                    </form>
                </div>
                
                <h1 style="margin-left:-0px; font-size:35px; margin-top:70px" >RECORDED SYMPTOMS</h1>
                <?php 
                // Display symptom search results or all symptoms
                    if ($symptom_result->num_rows > 0) {
                        echo "<table><tr>
                            <th>Form Number</th>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Symptoms</th>
                            <th>Duration (in days)</th>
                            <th>Lifestyle</th>
                            <th>Action</th>
                            </tr>";
                        // Output data of each row
        while ($row = $symptom_result->fetch_assoc()) {
            echo "<tr><td>" . $row["sub_num"] . "</td>" . "<td>" . $row["datesymp"] . "</td>" . "<td>" . $row["name"] . "</td>" . "<td>" . $row["symptom"] . "</td>" .
                "<td>" . $row["duration"] . "</td>" . "<td>" . $row["lifestyle"] . "<td>" . 
                "<a href='view_details.php?id=" . $row["User_ID"] . "' style='font-size:20px'>View Account</a>" .
                "</td></tr>";
        }
        echo "</table>";
                            } else {
                                echo "0 results";
                            }

                        ?> 
                        
                    </div>

            <div class="contain" style="margin-top:50px; margin-left: 1600px;; width:30%; background-color: #ffffffc0; padding: 10px; border-radius: 20px;"">
            <div class="search-container">
    <form action="" method="post" style= "background-color: #ffffffc0; padding: 5px; border-radius: 10px; width: 300px;">
        <input type="text" name="searchh" placeholder="Search Name..." id="searchInputDoctor">
        <button type="submit" class="smaller-button" style="margin-bottom:100px; " >Search</button>
    </form>
</div>

                <h1 style="margin-left:-0px;font-size:35px; margin-top:70px">DOCTOR'S ADVICE</h1>
                <?php
                // Display doctor's advice search results or all doctor's advice
                if ($advice_result->num_rows > 0) {
                    echo "<table><tr>
                        <th>Form Number</th>
                        <th>Date</th>
                        <th>User's Name</th>
                        <th>Recommended Medicine</th>
                        <th>Advice</th>
                        <th>Actions</th>
                        </tr>";

                    // Output data of each row
                        while ($row = $advice_result->fetch_assoc()) {
                            echo "<tr><td>" . $row["numberr"] . "</td>" . "<td>" . $row["datedoc"] . "</td>" . "<td>" . $row["patient"] . "</td>" . "<td>" . $row["recom_med"] . "</td>" . "<td>" .
                                $row["advice"] . "</td>" . "<td>" .
                                "<button onclick=\"openEditModal(" . $row['id'] . " , '". $row['patient'] . "' , '". $row['recom_med'] . "', '". $row['advice'] . "')\">Edit</button>" .
                                "&nbsp;&nbsp;<a href='delete_scpage.php?id=" . $row['id'] . "' onclick='return confirmDelete();'><button style='background-color: red;'>Delete</button></a>
                                </td></tr>";
                        }
                        echo "</table>";


                    // Close the result set
                    $advice_result->close();
                } else {
                    echo "0 results";
                }
                ?>
            </div>
        </div>
    </div>
  



                

    <!-- Add modal HTML -->
    <div id="editModal" class="modal">
    <div class="modal-content" style="background-color: #ffffffec; border-color: blue">
        <span class="close">&times;</span>
        <form action="edit_doc.php" method="post">
            <h2>Edit Information</h2>
            <input type="hidden" name="edit_id" id="edit_id">
            <div class="form-group">
                <label for="edit_patient">User's Name:</label>
                <input type="text" name="edit_patient" id="edit_patient" placeholder="Enter User's Name" class="box" required readonly>
            </div>
            <div class="form-group">
                <label for="edit_recom_med">Medicine Recommendation:</label>
                <input type="text" name="edit_recom_med" id="edit_recom_med" placeholder="Enter Medicine Recommendation" class="box" required>
            </div>
            <div class="form-group">
                <label for="edit_advice">Advice:</label>
                <input type="text" name="edit_advice" id="edit_advice" placeholder="Enter Advice" class="box" required>
            </div>
            <input type="submit" name="edit" class="btn" value="Save Changes">
        </form>
    </div>
</div>




    <!-- Custom JS for dropdown menu -->
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        let subMenu = document.getElementById("subMenu");
        let modal = document.getElementById("myModal");
        let closeModal = document.querySelector(".close");
        let confirmLogout = document.getElementById("confirmLogout");
        let cancelLogout = document.getElementById("cancelLogout");

        function toggleMenu() {
            subMenu.classList.toggle("open-menu");
        }

        // Add an event listener to the user-pic element to call the toggleMenu function when clicked
        document.querySelector('.user-pic').addEventListener('click', toggleMenu);

        // Add an event listener to the logout link to show a confirmation modal
        document.getElementById('logoutLink').addEventListener('click', function (event) {
            modal.style.display = "block";
        });

        // Close the modal when the user clicks on the close button
        closeModal.addEventListener('click', function () {
            modal.style.display = "none";
        });

        // Handle logout confirmation
        confirmLogout.addEventListener('click', function () {
            window.location.href = "log.out.php"; // Redirect to logout script
        });

        // Handle cancel logout
        cancelLogout.addEventListener('click', function () {
            modal.style.display = "none"; // Close the modal
        });

        // Close the modal when the user clicks anywhere outside of it
        window.onclick = function (event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };
    });
</script>



    
    <script>
    // Get the modal
    var modal = document.getElementById('editModal');

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

function openEditModal(id, patient, recom_med, advice) {
  document.getElementById('edit_id').value = id;
  document.getElementById('edit_patient').value = patient;
  document.getElementById('edit_recom_med').value = recom_med;
  document.getElementById('edit_advice').value = advice;
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this record?");
    }
</script>



</body>
</html>

