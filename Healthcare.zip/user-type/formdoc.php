<?php
    include 'config.php';
    session_start();

    if (!isset($_SESSION['doctor_name'])) {
        header('location:login_form.php');
    }

    // Check if user is logged in
    if(!isset($_SESSION['user_id'])) {
        // Redirect to login page if not logged in
        header('Location: login_form.php');
        exit();
    }

    $user_id = $_SESSION['user_id'];

    // Retrieve user details from the database
    $select = $conn->prepare("SELECT * FROM user_form WHERE user_id = ?");
    $select->bind_param("i", $user_id);
    $select->execute();
    $result = $select->get_result();

    if($result->num_rows > 0){
        $user = $result->fetch_assoc();
    } else {
        // Handle case where user details are not found
        echo "User details not found!";
        exit();
    }

    // Check if the update form is submitted
    if(isset($_POST['update'])){
        // Retrieve updated form data
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $age = mysqli_real_escape_string($conn, $_POST['age']);
        $sex = mysqli_real_escape_string($conn, $_POST['sex']);
        $contact = mysqli_real_escape_string($conn, $_POST['contact']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        
        // Update user details in the database
        $update = $conn->prepare("UPDATE user_form SET username = ?, email = ?, age = ?, sex = ?, contact = ?, address = ? WHERE user_id = ?");
        $update->bind_param("ssssssi", $username, $email, $age, $sex, $contact, $address, $user_id);
        $update->execute();

        if($update){
            // Redirect to the same page to refresh user details
            header('Location: formdoc.php');
            exit();
        } else {
            $error = 'User details update failed!';
        }
    }
    ?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="13.css">
    <title>User Page</title>
</head>
<body>
<div class="hero" >
        <nav>
            <a class="logo">Virtual Health Coach</a>
            <ul>
                <li><a href="doctor_page.php">About</a></li>
                <li><a href="sc_doc.php">Symptom Checker</a></li>
                <li><a href="he_doc.php">Healthcare Education</a></li>
                <li><a href="f_doc.php">FAQ</a></li>
            </ul>
            <img src="9.png" class="user-pic" onclick="toggleMenu()">

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="ai.png">
                        <h3><span><?php echo $_SESSION['doctor_name'] ?></span></h3>
                    </div>
                    <hr>

                    <a href="formdoc.php" class="sub-menu-link">
                        <img src="10.png">
                        <p>Doctor Details</p>
                        <span>></span>
                    </a>

                        <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                            <img src="3.png">
                            <p>Logout</p>
                            <span>></span>
                        </a>
                </div>
            </div>
        </nav>

        <div class="page-content page-container" id="page-content">
            <div class="padding">
                <div class="row container d-flex justify-content-center">
                    <div class="col-xl-6 col-md-12">
                        <div class="card user-card-full">
                            <div class="row m-l-0 m-r-0">
                                <div class="col-sm-4 bg-c-lite-green user-profile">
                                    <div class="card-block text-center text-white">
                                        <div class="m-b-25">
                                            <img src="aq.png" class="img-radius" alt="User-Profile-Image">
                                        </div>
                                        <h6 class="f-w-600">Dr. <?php echo $_SESSION['doctor_name']; ?></h6>
                                        <i class="mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16"></i>
                                    </div>
                                </div>
                                <div class="col-sm-8">
                                    <div class="card-block">
                                    <button onclick="toggleUpdateForm()" id="but">Edit</button>
                                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <p class="m-b-10 f-w-600">Email</p>
                                                <h6 class="text-muted f-w-400"><?php echo $user['email']; ?></h6>
                                            </div>
                                            <div class="col-sm-6">
                                                <p class="m-b-10 f-w-600">Age</p>
                                                <h6 class="text-muted f-w-400"><?php echo $user['age']; ?></h6>
                                                <p class="m-b-10 f-w-600">Sex</p>
                                                <h6 class="text-muted f-w-400"><?php echo $user['sex']; ?></h6>
                                                <p class="m-b-10 f-w-600">Phone</p>
                                                <h6 class="text-muted f-w-400"><?php echo $user['contact']; ?></h6>
                                                <p class="m-b-10 f-w-600">Address</p>
                                                <h6 class="text-muted f-w-400"><?php echo $user['address']; ?></h6>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Button to toggle Update Form -->
              
                </div>
                <!-- Modal Overlay -->
                <div id="updateFormOverlay" class="modal-overlay" style="display: none;">
                    <div class="modal">
                        <span class="close" onclick="closeUpdateForm()">&times;</span>
                        <div class="update-form">
                            <h2>Update Details</h2>
                            <?php if(isset($error)): ?>
                                <div class="message"><?php echo $error; ?></div>
                            <?php endif; ?>
                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="username">Username:</label>
                                    <input type="text" name="username" id="username" placeholder="Enter Username" class="box" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="email" name="email" id="email"  placeholder="Enter Email" class="box" required>
                                </div>
                                <div class="form-group">
                                    <label for="age">Age:</label>
                                    <input type="text" name="age" id="age" placeholder="Enter Age" class="box" required>
                                </div>
                                <div class="form-group">
                                    <label for="sex">Sex:</label>
                                    <input type="text" name="sex" id="sex"  placeholder="Enter Sex" class="box" required>
                                </div>
                                <div class="form-group">
                                    <label for="contact">Contact:</label>
                                    <input type="text" name="contact" id="contact"  placeholder="Enter Contact" class="box" required>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address:</label>
                                    <input type="text" name="address" id="address"  placeholder="Enter Address" class="box" required>
                                </div>
                                <input type="submit" name="update" value="Update Details" class="btn">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>



</div>


<script>
            function toggleMenu() {
                var subMenu = document.getElementById("subMenu");
                subMenu.classList.toggle("open-menu");
            }

            function toggleUpdateForm() {
                var updateFormOverlay = document.getElementById("updateFormOverlay");
                updateFormOverlay.style.display = "block";
            }

            function closeUpdateForm() {
                var updateFormOverlay = document.getElementById("updateFormOverlay");
                updateFormOverlay.style.display = "none";
            }

            document.getElementById('logoutLink').addEventListener('click', function(event) {
                if (!confirm("Are you sure you want to logout?")) {
                    event.preventDefault();
                }
            });
        </script>


</body>
</html>
