Create database in phpMyAdmin: "user_db"

Import sql files from database folder in this file:
	doctors_advice
	user_form
	symptoms
	tbl_faq


Run the program on your browser: "localhost/user-type/home.php"

Other Details
Host name: localhost
Username: root
Password: 123ABC12
Database: user_db

to access our databse, change config.inc.php in phpMyAdimin in xampp folder 
auth_type = 'cookie';
'user' = 'root';
'password' = '123ABC12'
'AllowNoPassword' = false;

Doctor's Account
	username: kaye
	password: odoriko12
	
	username: qu
	password: asdqweasd


User Accounts
	username: nins
	password: nins12


	username: kat
	password: asdqweasd

	
	username: nina
	password: odoriko12