<?php
include 'config.php';
session_start();

if(isset($_POST['submit'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $select = $conn->prepare("SELECT * FROM user_form WHERE username = ?");
    $select->bind_param("s", $username);
    $select->execute();
    $result = $select->get_result();

    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];

        if(password_verify($password, $hashed_password)){
            // User authenticated successfully
            $user_type = $row['user_type'];
            $user_id = $row['user_id']; // Retrieve user ID from the database using 'User_ID'

            // Store user details in session variables
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $row['username'];
            $_SESSION['user_type'] = $user_type;

            // Redirect based on user type
            if($user_type == 'doctor'){
                $_SESSION['doctor_name'] = $row['username'];
                header('Location: doctor_page.php');
                exit();
            } elseif($user_type == 'user'){
                $_SESSION['user_name'] = $row['username'];
                header('Location: user_page.php');
                exit();
            }
        } else {
            $error = 'Incorrect username or password!';
        }
    } else {
        $error = 'Incorrect username or password!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login Form</title>
   
   <link rel="stylesheet" href="s.css">
</head>
<body>
   
<div class="form-container" id="contain">
    <form action="" method="post" enctype="multipart/form-data">
        <h2>Login Now</h2>
        <?php if(isset($error)): ?>
            <div class="message"><?php echo $error; ?></div>
        <?php endif; ?>
        <input type="text" name="username" placeholder="Enter username" class="box" required>
        <input type="password" name="password" placeholder="Enter password" class="box" required>
        <input type="submit" name="submit" value="Login Now" class="btn">
        <p>Don't have an account? <a href="register.php">REGISTER NOW</a></p>
    </form>
</div>

</body>
</html>
