<?php
include('config.php');

if(isset($_POST['edit'])){
    $sub_num = $_POST['editSubNum'];
    $symptom=$_POST['editSymptom'];
    $duration=$_POST['editDuration'];
    $lifestyle=$_POST['editLifestyle'];

    // Update the record in the database based on sub_num
    $sql = "UPDATE symptoms 
            SET symptom='$symptom', duration='$duration', lifestyle='$lifestyle' WHERE sub_num='$sub_num'";
    
    if (mysqli_query($conn, $sql)) {
        // Redirect back to the page where the table is displayed
        header('location:sc.php');
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>
