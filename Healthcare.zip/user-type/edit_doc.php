<?php
include 'config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $edit_id = mysqli_real_escape_string($conn, $_POST['edit_id']);
    $edit_recom_med = mysqli_real_escape_string($conn, $_POST['edit_recom_med']);
    $edit_advice = mysqli_real_escape_string($conn, $_POST['edit_advice']);
  
    // Update the record with the provided data
    $sql = "UPDATE `doctors_advice` SET recom_med='$edit_recom_med', advice='$edit_advice' WHERE id=$edit_id";
  
    if (mysqli_query($conn, $sql)) {
        // Redirect back to the page where the table is displayed
        header('Location: sc_doc.php');
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>
