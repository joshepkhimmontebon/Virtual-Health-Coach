<?php
    @include 'config.php';
    session_start();
    if(!isset($_SESSION['doctor_name'])){
       header('location:login_form.php');
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ Doctor</title>
    
    <link rel="stylesheet" href="d.css">
</head>
<body>
    <div class="hero">
        <nav>
            <a href="#" class="logo">Virtual Health Coach</a>
            <ul>
            <li><a href="doctor_page.php">About</a></li>
            <li><a href="sc_doc.php">Symptom Checker</a></li>
            <li><a href="he_doc.php">Healthcare Education</a></li>
            <li><a href="f_doc.php">FAQ</a></li>
            </ul>
            <img src="9.png" class="user-pic" onclick="toggleMenu()">
            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="ai.png">
                        <h3><span><?php echo $_SESSION['doctor_name'] ?></span></h3>
                    </div>
                    <hr>
                    <a href="formdoc.php" class="sub-menu-link">
                        <img src="10.png">
                        <p>Doctor Details</p>
                        <span>></span>
                    </a>

                        <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                            <img src="3.png">
                            <p>Logout</p>
                            <span>></span>
                        </a>
                </div>
            </div>
        </nav>
   
    <div class="container">
    <div class="title-container text-center mb-3">
        <h1>Frequently Asked Questions</h1>
        <div class="buttons">
            <button class="btn btn-dark" data-toggle="modal" data-target="#addFaqModal">Add FAQ</button>
            <button class="btn btn-success" onclick="showAllActionButtons()">Manage FAQ</button>
        </div>
    </div>
    <?php 
        include("conn.php");
        if(isset($_GET['faq'])) {
            // Delete the FAQ
            $deleteID = $_GET['faq'];
            $stmt = $conn->prepare("DELETE FROM tbl_faq WHERE tbl_faq_id = :id");
            $stmt->bindParam(':id', $deleteID);
            $stmt->execute();
            
            // Redirect to avoid re-deletion on page refresh
            header("Location: f_doc.php");
            exit(); // Ensure that no further code execution occurs after redirect
        }
        
        // Retrieve FAQs after deletion
        $stmt = $conn->prepare("SELECT * FROM tbl_faq");
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach($result as $row) {
            $faqID = $row["tbl_faq_id"];
            $question = $row["question"];
            $answer = $row["answer"];
    ?>
    <div class="wrapper">
        <button class="toggle">
            <span id="question-<?= $faqID ?>"><?= $question ?></span>
            <i class="fa-solid fa-plus icon"></i>
        </button>
        <div class="content">
            <p id="answer-<?= $faqID ?>"><?= $answer ?></p>
        </div>
        <div class="action-button float-right" style="display: none;">
            <button class="btn btn-primary btn-sm" onclick="updateFaq(<?= $faqID ?>)"><img src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png" alt=""></button>
            <button class="btn btn-danger btn-sm" onclick="deleteFaq(<?= $faqID ?>)"><img src="https://cdn-icons-png.flaticon.com/512/1214/1214428.png" alt=""></button>
        </div>
    </div>
    <?php } ?>
    <!-- Modals -->
    <div class="modal fade" id="addFaqModal" tabindex="-1" aria-labelledby="addFaq" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addFaq">Add FAQ</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="add-faq.php" method="POST">
                        <div class="form-group">
                            <label for="question">Frequently Asked Question:</label>
                            <input type="text" class="form-control" id="question" name="question">
                        </div>
                        <div class="form-group">
                            <label for="answer">Answer:</label>
                            <textarea class="form-control" name="answer" id="answer" cols="30" rows="7"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="updateFaqModal" tabindex="-1" aria-labelledby="updateFaq" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateFaq">Update FAQ</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="update-faq.php" method="POST">
                        <input type="text" class="form-control" id="updateFaqID" name="tbl_faq_id">
                        <div class="form-group">
                            <label for="updateQuestion">Frequently Asked Question:</label>
                            <input type="text" class="form-control" id="updateQuestion" name="question">
                        </div>
                        <div class="form-group">
                            <label for="updateAnswer">Answer:</label>
                            <textarea class="form-control" name="answer" id="updateAnswer" cols="30" rows="7"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let subMenu = document.getElementById("subMenu");
            function toggleMenu() {
                subMenu.classList.toggle("open-menu");
                
            }
            document.querySelector('.user-pic').addEventListener('click', toggleMenu);
            document.getElementById('logoutLink').addEventListener('click', function(event) {
                if (!confirm("Are you sure you want to logout?")) {
                    event.preventDefault();
                }
            });
        });
        let toggles = document.getElementsByClassName('toggle');
        let contentDiv = document.getElementsByClassName('content');
        let icons = document.getElementsByClassName('icon');
        for(let i=0; i<toggles.length; i++){
            toggles[i].addEventListener('click', ()=>{
                if( parseInt(contentDiv[i].style.height) != contentDiv[i].scrollHeight){
                    contentDiv[i].style.height = contentDiv[i].scrollHeight + "px";
                    toggles[i].style.color =  "crimson";
                }
                else{
                    contentDiv[i].style.height = "0px";
                    toggles[i].style.color = "#111130";
                }
                for(let j=0; j<contentDiv.length; j++){
                    if(j!==i){
                        contentDiv[j].style.height = "0px";
                        toggles[j].style.color = "#333";
                    }
                }
            });
        }
        function showAllActionButtons() {
            let actionButtons = document.querySelectorAll('.action-button');
            actionButtons.forEach(button => {
                if (button.style.display === 'none' || button.style.display === '') {
                    button.style.display = 'block';
                } else {
                    button.style.display = 'none';
                }
            });
        }
        function updateFaq(id) {
            $("#updateFaqModal").modal("show");
            let updateQuestion = $("#question-" + id).html();
            let updateAnswer = $("#answer-" + id).html();
            $("#updateFaqID").val(id);
            $("#updateQuestion").val(updateQuestion);
            $("#updateAnswer").val(updateAnswer);
        }
        function deleteFaq(id) {
            if (confirm("Do you want to delete this faq?")) {
                window.location = "f_doc.php?faq=" + id;
            }
        }
    </script>
</body>
</html>