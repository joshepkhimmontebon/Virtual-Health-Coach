<?php

$conn = mysqli_connect('localhost','root','123ABC12','user_db') or die('connection failed');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
	$id=$_GET['id'];
	
	mysqli_query($conn,"delete from `doctors_advice` where id='$id'");
	header('location:sc_doc.php');
?>