<?php
// Include config file
include 'config.php';

// Attempt select query execution
$sql = "SELECT * FROM `user_form`";
$result = mysqli_query($conn, $sql);

// Check if there are records
if (mysqli_num_rows($result) > 0) {
    echo "<table>";
    echo "<tr>";
    echo "<th>Username</th>";
    echo "<th>Email</th>";
    echo "<th>Age</th>";
    echo "<th>Sex</th>";
    echo "<th>Contact</th>";
    echo "<th>Address</th>";
    echo "</tr>";
    
    // Fetch and display each row of the result set
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>".$row['username']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td>".$row['age']."</td>";
        echo "<td>".$row['sex']."</td>";
        echo "<td>".$row['contact']."</td>";
        echo "<td>".$row['address']."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No records found";
}

// Close connection
mysqli_close($conn);
?>
