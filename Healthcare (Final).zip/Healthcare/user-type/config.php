<?php

$conn = mysqli_connect('localhost','root','123ABC12','user_db') or die('connection failed');

?>