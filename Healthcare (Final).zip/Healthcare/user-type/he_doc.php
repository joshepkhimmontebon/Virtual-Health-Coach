<?php
@include 'config.php';
session_start();
if (!isset($_SESSION['doctor_name'])) {
    header('location:login_form.php');
}
?>
<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>Mediplus - Free Medical and Doctor Directory HTML Template.</title>
		
		<!-- Favicon -->
        <link rel="icon" href="img/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="al.css">
        <link rel="stylesheet" href="style.css">
		<link href="style1.css" rel="stylesheet"/>
        <link rel="stylesheet" href="css/responsive.css">
		
    </head>
    <body>
	
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
		
		
	
        <nav>
    <a class="logo">Virtual Health Coach</a>
    <ul>
        <li><a href="doctor_page.php">About</a></li>
        <li><a href="sc_doc.php">Symptom Checker</a></li>
        <li><a href="he_doc.php">Healthcare Education</a></li>
        <li><a href="f_doc.php">FAQ</a></li>
    </ul>
    <img src="9.png" class="user-pic" onclick="toggleMenu()">
    <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="ai.png">
                <h3><span><?php echo $_SESSION['doctor_name'] ?></span></h3>
            </div>
            <hr>
            <a href="formdoc.php" class="sub-menu-link">
                <img src="10.png">
                <p>Doctor    Details</p>
                <span>></span>
            </a>
            <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                <img src="3.png">
                <p>Logout</p>
                <span>></span>
            </a>
        </div>
    </div>
</nav>

			
							
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
		<!-- End Header Area -->
		
		<!-- Slider Area -->
		<section class="slider">
			<div class="hero-slider">
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('img/slider2.jpg')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1>Unlocking Knowledge for Healthier, Happier Lives: <span>Empowering Individuals</span> with the Insights <span>They Need to Thrive!</span></h1>
									<p>Enhancing Health and Wellness for Every Individual by Providing Accessible Insights and Resources for Sustainable Living and Thriving. </p>
									<div class="button">
										<a href="https://www.cdc.gov/healthyyouth/health-education/index.htm" class="btn primary">Learn More</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Single Slider -->
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('img/slider.jpg')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1>Knowledge <span>for Healthier Lives:</span> Empowering Health <span>Through Knowledge.</span></h1>
									<p>
										At Knowledge for Healthier Lives, we're dedicated to providing accessible, reliable health information to empower informed choices. Our platform offers clear, expert-backed resources on nutrition, fitness, mental health, and more. Join us on the journey to happier, healthier living through the power of knowledge.</p>
									<div class="button">
										<a href="doctor_page.php" class="btn primary">About Us</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Start End Slider -->
				<!-- Start Single Slider -->
				<div class="single-slider" style="background-image:url('img/slider3.jpg')">
					<div class="container">
						<div class="row">
							<div class="col-lg-7">
								<div class="text">
									<h1>We Provide <span>Medical</span> Services That You Can <span>Trust!</span></h1>
									<p>Experience Trusted Excellence: Our Comprehensive Suite of Medical Services Ensures Your Well-being and Peace of Mind. </p>
									<div class="button">
										<a href="sc_doc.php" class="btn">Symptom Checker</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- End Single Slider -->
			</div>
		</section>
		<!--/ End Slider Area -->
		
		<!-- Start Schedule Area -->
		<section class="schedule">
			<div class="container">
				<div class="schedule-inner">
					<div class="row">
						<div class="col-lg-4 col-md-6 col-12 ">
							<!-- single-schedule -->
							<div class="single-schedule first">
								<div class="inner">
									<div class="icon">
										<i class="fa fa-ambulance"></i>
									</div>
									<div class="single-content">
										<span>Richard M. Fairbanks</span>
										<h4>10 TIPS FOR MAINTAINING A HEALTHY
											LIFESTYLE AND BODY WEIGHT</h4>
										<p>basic tips and resources for how to maintain your healthy lifestyle, body weight, and
											overall well-being while staying home and engaging in social distancing.</p>
										<a href="https://fairbanks.indianapolis.iu.edu/doc/10-Tips-Healthy-Lifestyle.pdf">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-12">
							<!-- single-schedule -->
							<div class="single-schedule middle">
								<div class="inner">
									<div class="icon">
										<i class="icofont-prescription"></i>
									</div>
									<div class="single-content">
										<span>Virginia Mason Franciscan Health</span>
										<h4>Patient Rights and Responsibilities</h4>
										<p>As a patient, it’s a good idea to educate yourself about your rights and responsibilities. As always, our staff is available to answer any questions you may have.</p>
										<a href="https://www.vmfh.org/patient-and-visitor-information/patient-information/patient-rights-responsibilities">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-12 col-12">
							<!-- single-schedule -->
							<div class="single-schedule last">
								<div class="inner">
									<div class="icon">
										<i class="icofont-ui-clock"></i>
									</div>
									<div class="single-content">
											<span>Princeton University</span>
											<h4>Common Illnesses</h4>
											<p>provide quality medical, health and wellness services to Princeton University undergraduate and graduate students, their dependents, and faculty and staff. UHS is committed to contributing to a healthy learning and working environment.</p>
											<a href="https://uhs.princeton.edu/health-resources/common-illnesses">LEARN MORE<i class="fa fa-long-arrow-right"></i></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/End Start schedule Area -->

		<!-- Start Feautes -->
		<section class="Feautes section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>We Are Always Ready to Help You & Your Family</h2>
							<img src="img/section-img.png" alt="#">
							<p>Compassionate Guidance for Your Family's Well-being: Explore Our Free Consultation Services Today</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<i class="icofont icofont-ambulance-cross"></i>
							</div>
							<h3>Emergency Help</h3>
							<p>Immediate Support: Your Lifeline in Urgent Situations</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features">
							<div class="signle-icon">
								<i class="icofont icofont-medical-sign-alt"></i>
							</div>
							<h3>Enriched Pharmecy</h3>
							<p>Accessible Healthcare for All: Empowering Health Solutions for Those in Need</p>
						</div>
						<!-- End Single features -->
					</div>
					<div class="col-lg-4 col-12">
						<!-- Start Single features -->
						<div class="single-features last">
							<div class="signle-icon">
								<i class="icofont icofont-stethoscope"></i>
							</div>
							<h3>Medical Treatment</h3>
							<p>Accessible Healthcare Solutions: Free Consultations for Those in Need</p>
						</div>
						<!-- End Single features -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Feautes -->
		
		
		<!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Preventive Care Guidelines</h2>
							<img src="img/section-img.png" alt="#">
							<p>offer expert recommendations for screenings, vaccinations, and lifestyle changes to prevent illnesses or detect them early, improving health outcomes.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>For Children and Adolescents</h3>
							<p>Vaccinations: Protecting against infectious diseases is crucial during childhood and adolescence. Ensure your child receives all recommended vaccinations according to the schedule provided by healthcare professionals.</p>
							<p>Well-child Visits: Regular check-ups with pediatricians or family doctors are vital for monitoring growth, development, and overall health. These visits also provide opportunities for discussing any concerns or questions you may have about your child's well-being.</p>
						
							<h3>For Adults</h3>
							<p>Screenings: Routine screenings for conditions such as cancer, heart disease, diabetes, and hypertension are essential for early detection and intervention. Stay informed about the recommended screening guidelines for your age and risk factors, and discuss them with your healthcare provider.</p>
							<p>Health Check-ups: Annual wellness exams are key to assessing your overall health status, identifying any potential issues, and developing personalized prevention plans. These check-ups typically include measurements of vital signs, discussion of lifestyle factors, and screenings as appropriate.</p>
						
							<h3>For Older Adults</h3>
							<p>Immunizations: As we age, our immune system may weaken, making us more susceptible to certain infections. Stay up-to-date with recommended vaccinations, including flu shots, pneumonia vaccines, and shingles vaccines.</p>
							<p>Screening Tests: Aging is associated with an increased risk of certain health conditions, such as osteoporosis, cognitive decline, and vision and hearing impairment. Regular screenings and evaluations can help detect these issues early and enable prompt intervention.</p>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=b7hnc196kls" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->
		
		
		
		<!-- Start service -->
		<section class="services section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>We Offer Different Services To Improve Your Health</h2>
							<img src="img/section-img.png" alt="#">
							<p>We provide a diverse range of health services tailored to your needs, ensuring comprehensive care and support for your well-being.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-prescription"></i>
							<h4><a href="https://www.privatehealth.gov.au/health_insurance/howitworks/treatments.htm">General Treatment</a></h4>
							<p>Our comprehensive treatment options encompass a wide spectrum of medical services, designed to address your unique health needs and foster your overall wellness. </p>	
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-tooth"></i>
							<h4><a href="https://www.mayoclinic.org/healthy-lifestyle/adult-health/in-depth/dental/art-20047475">Oral Health</a></h4>
							<p>Oral health is essential for overall well-being. Our services focus on promoting and maintaining optimal dental hygiene, ensuring a healthy smile and a confident you. </p>	
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-heart-alt"></i>
							<h4><a href="https://health.gov/myhealthfinder/health-conditions/heart-health/keep-your-heart-healthy">Cardiac Health</a></h4>
							<p>Our cardiac services are tailored to promote heart health through prevention, diagnosis, and treatment, ensuring optimal cardiovascular function and a healthier, happier life. </p>	
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-listening"></i>
							<h4><a href="https://www.webmd.com/cold-and-flu/ear-infection/ear-pain-home-treatment">Ear Treatment</a></h4>
							<p>Our ear treatment services cover everything from routine earwax management to advanced treatments for hearing loss and infections, ensuring your comfort and well-being. </p>	
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-eye-alt"></i>
							<h4><a href="https://www.webmd.com/eye-health/understanding-vision-problems-symptoms">Vision Problems</a></h4>
							<p>Our vision services address a range of eye health concerns, offering solutions for common issues like refractive errors to more complex conditions, ensuring clear sight and optimal eye health for all. </p>	
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="icofont icofont-blood"></i>
							<h4><a href="https://my.clevelandclinic.org/health/treatments/14755-blood-transfusion">Blood Transfusion</a></h4>
							<p>Our blood transfusion services provide life-saving support, delivering vital blood components to those in need, ensuring patients receive the critical care necessary for their recovery and well-being. </p>	
						</div>
						<!-- End Single Service -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End service -->
		
		
		
		
		
		<!-- Start Blog Area -->
		<section class="blog section" id="blog">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Keep up with Our Most Recent Medical News.</h2>
							<img src="img/section-img.png" alt="#">
							<p>Lorem ipsum dolor sit amet consectetur adipiscing elit praesent aliquet. pretiumts</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<div class="single-news">
							<div class="news-head">
								<img src="img/blog1.jpg" alt="#">
							</div>
							<div class="news-body">
								<div class="news-content">
									<div class="date">22 Aug, 2020</div>
									<h2><a href="https://www.uwhealth.org/news/know-the-difference-between-a-cold-and-the-flu">Know the difference between a cold and the flu</a></h2>
									<p class="text">Not every infectious disease, such as a cold or the flu, can be treated by your health care provider. By knowing the various symptoms and treatment solutions, you can avoid unnecessary visits to the doctor. You'll also be able to identify conditions that need medical attention.</p>
								</div>
							</div>
						</div>
						<!-- End Single Blog -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<div class="single-news">
							<div class="news-head">
								<img src="img/blog2.jpg" alt="#">
							</div>
							<div class="news-body">
								<div class="news-content">
									<div class="date">15 Jul, 2020</div>
									<h2><a href="https://mogrendental.com/5-common-dental-problems-and-solutions/">Top five way for solving teeth problems.</a></h2>
									<p class="text">Nobody wants to deal with dental problems, but even those who follow a diligent oral health routine of brushing and flossing and regular check-ups can find themselves with tooth troubles, and that’s no fun! </p>
								</div>
							</div>
						</div>
						<!-- End Single Blog -->
					</div>
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Blog -->
						<div class="single-news">
							<div class="news-head">
								<img src="img/blog3.jpg" alt="#">
							</div>
							<div class="news-body">
								<div class="news-content">
									<div class="date">05 Jan, 2020</div>
									<h2><a href="https://newsinhealth.nih.gov/2022/01/it-flu-covid-19-allergies-or-cold">Is It Flu, COVID-19, Allergies, or a Cold?</a></h2>
									<p class="text">Feeling sick can be especially concerning these days. Could your sniffles be caused by COVID-19? Or the flu? A cold? Or maybe allergies?</p>
								</div>
							</div>
						</div>
						<!-- End Single Blog -->
					</div>
				</div>
			</div>
		</section>
		<!-- End Blog Area -->
		
		
		
		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer">
								<h2>About Us</h2>
								<p> an innovative system designed to provide personalized health guidance and support to individuals through digital platforms such as mobile apps or websites. Its primary function revolves around offering comprehensive health management services tailored to the user's specific needs and goals.</p>
								<!-- Social -->
								<ul class="social">
									<li><a href="#"><i class="icofont-facebook"></i></a></li>
									<li><a href="#"><i class="icofont-google-plus"></i></a></li>
								</ul>
								<!-- End Social -->
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Quick Links</h2>
								<div class="row">
									<div class="col-lg-6 col-md-6 col-12">
										<ul>
											<li><a href="doctor_page.php"><i class="fa fa-caret-right" aria-hidden="true"></i>About Us</a></li> <br>
											<li><a href="f_doc.php"><i class="fa fa-caret-right" aria-hidden="true"></i>FAQ</a></li>	
										</ul>
									</div>
								</div>
							</div>
						</div>
						
						
					</div>
				</div>
			</div>
			<!--/ End Footer Top -->
			
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    <!-- Code injected by live-server -->

	<script>
function toggleMenu() {
    const subMenu = document.getElementById("subMenu");
    subMenu.classList.toggle("open-menu");
}
</script>

<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>
</html>