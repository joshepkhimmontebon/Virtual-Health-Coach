<?php

include 'config.php';
session_start();
if (!isset($_SESSION['user_name'])) {
    header('location:login_form.php');
}

// Check if the form is submitted
if (isset($_POST['add'])) {
    // Escape user inputs for security
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $datesymp = mysqli_real_escape_string($conn, $_POST['datesymp']);
    $symptom = mysqli_real_escape_string($conn, $_POST['symptom']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $lifestyle = mysqli_real_escape_string($conn, $_POST['lifestyle']);

    // Get the User_ID based on the username
    $user_name = $_SESSION['user_name'];
    $user_query = "SELECT User_ID FROM user_form WHERE username = '$user_name'";
    $user_result = mysqli_query($conn, $user_query);
    $user_row = mysqli_fetch_assoc($user_result);
    $user_id = $user_row['User_ID'];

    // Attempt to insert data into the database with the retrieved User_ID
    $sql = "INSERT INTO `symptoms` (User_ID, name, datesymp, symptom, duration, lifestyle) 
    VALUES ('$user_id', '$name', '$datesymp', '$symptom', '$duration', '$lifestyle')";

    if (mysqli_query($conn, $sql)) {
        echo "Records added successfully.";
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
}

// Check if the form is submitted for searching symptoms
if (isset($_POST['searcha'])) {
    $search = mysqli_real_escape_string($conn, $_POST['searcha']);
    $sql = "SELECT * FROM symptoms WHERE symptom LIKE '%$search%' AND name='{$_SESSION['user_name']}'";
    $symptom_result = $conn->query($sql);
} else {
    // Default query to display all symptoms
    $sql = "SELECT * FROM symptoms WHERE name='{$_SESSION['user_name']}'";
    $symptom_result = $conn->query($sql);
}

// Check if the form is submitted for searching doctor's advice
if (isset($_POST['searchb'])) {
    $search = mysqli_real_escape_string($conn, $_POST['searchb']);
    $sql = "SELECT * FROM doctors_advice WHERE numberr LIKE '%$search%' AND patient='{$_SESSION['user_name']}'";
    $doctor_result = $conn->query($sql);
} else {
    // Default query to display all doctor's advice
    $sql = "SELECT * FROM doctors_advice WHERE patient='{$_SESSION['user_name']}'";
    $doctor_result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">



<head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Healthcare at Your Fingertips</title>
    <link href="al.css" rel="stylesheet" />
    <link href="style1.css" rel="stylesheet" />
    <!-- Font Awesome icons (free version) -->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap) -->
    <link href="css/styles.css" rel="stylesheet" />
    <title>Fill Up Form</title>
</head>


<body>

    <div class="hero" style="background-image: url('aa.jpg'); background-repeat: no-repeat; background-size: cover ">
        <link rel="stylesheet" href="9.css">
        <link rel="stylesheet" href="style1.css">
        <nav>
            <a href="#" class="logo">Healthcare at Your Fingertips</a>
            <ul>
                <li><a href="user_page.php">About</a></li>
                <li><a href="sc.php">Symptom Checker</a></li>
                <li><a href="he.php">Healthcare Education</a>
                <li><a href="faq.php">FAQ</a>
                <li><a href="ca.php">Contact Us</a>
            </ul>
            <img src="6.png" class="user-pic" onclick="toggleMenu()">
            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <img src="5.png">
                        <h3><span><?php echo $_SESSION['user_name'] ?></span></h3>
                    </div>
                    <hr>
                    <a href="formuser.php" class="sub-menu-link">
                        <img src="10.png">
                        <p>User Details</p>
                        <span>></span>
                    </a>

                    <a href="log.out.php" class="sub-menu-link" id="logoutLink">
                        <img src="3.png">
                        <p>Logout</p>
                        <span>></span>
                    </a>
                    
                </div>
            </div>
        </nav>

        <div class="form-container" style="margin-left: -800px;" id="contain" >
            <link rel="stylesheet" href="cc.css">
            <link rel="stylesheet" href="sc.css">
            <link rel="stylesheet" href="checker.css">
            <form action="" method="post" enctype="multipart/form-data" style="background-color: #ffffffc0;">
                <h2>Fill Up Form</h2>
                <?php
                if (isset($message)) {
                    foreach ($message as $msg) {
                        echo '<div class="message">' . $msg . '</div>';
                    }
                }
                ?>
                <input type="text" name="name" placeholder="Enter User Name" class="box" required>
                <input type="date" name="datesymp" class="box" required>
                <input type="text" name="symptom" placeholder="Enter Symptoms" class="box" required>
                <input type="longtext" name="duration" placeholder="Enter Duration (in days)" class="box" required>
                <input type="longtext" name="lifestyle" placeholder="Enter Lifestyle" class="box" required>
                <input type="submit" name="add" class="btn">
            </form>
        </div>

        <div class="contain" style="margin-top:-700px; margin-left:700px; padding: 10px; border-radius: 20px; background-color: #ffffffc0;">
            <div class="search-container">
                <form action="" method="post" style="background-color: #ffffffc0; padding: 5px; border-radius: 10px;">
                    <input type="text" name="searcha" placeholder="Search Symptom..." id="searchInput">
                    <button type="submit" style="margin-bottom:100px; ">Search</button>
                </form>
            </div>
            <h1>FORM RECORD</h1>
            <?php
            // Display search results or all records
            if ($symptom_result->num_rows > 0) {
                echo "<table><tr>
                <th>Form Number</th>
                <th>Date</th>
                <th>Symptoms</th>
                <th>Duration (in days)</th>
                <th>Lifestyle</th>
                <th>Action</th>
                </tr>";
                // Output data of each row
                while ($row = $symptom_result->fetch_assoc()) {
                    echo "<tr><td>" . $row["sub_num"]. "</td>" . "<td>" . $row["datesymp"] . "</td>" . "<td>" . $row["symptom"] . "</td>" .
                        "<td>" . $row["duration"] . "</td>" . "<td>" . $row["lifestyle"] . "</td>" .
                        "<td><button onclick=\"openModal(" . $row["sub_num"] . ", '" . $row['symptom'] . "', '" . $row['duration'] . "', '" . $row['lifestyle'] . "')\">Edit</button>
                        &nbsp;&nbsp;<a href='delete_page.php?id=" . $row["sub_num"] . "' onclick='return confirmDelete();'><button style='background-color: red;'>Delete</button></a>
                        </td></tr>";
                }                
                echo "</table>";
            } else {
                echo "0 results";
            }
            ?>
        </div>
        
        <!-- Add modal HTML -->
        <div id="editModal" class="modal">
            <div class="modal-content"  style="background-color: #ffffffec; border-color: blue">
                <span class="close" >&times;</span>
                <form action="edit.php" method="post">
                    <h2>Edit Information</h2>
                    <input type="hidden" id="editSubNum" name="editSubNum">
                    <div class="form-group">
                        <label for="editSymptom">Symptoms:</label>
                        <input type="text" id="editSymptom" name="editSymptom" placeholder="Enter Symptoms" class="box" required>
                    </div>
                    <div class="form-group">
                        <label for="editDuration">Duration (in days):</label>
                        <input type="text" id="editDuration" name="editDuration" placeholder="Enter Duration (in days)" class="box" required>
                    </div>
                    <div class="form-group">
                        <label for="editLifestyle">Lifestyle:</label>
                        <input type="text" id="editLifestyle" name="editLifestyle" placeholder="Enter Lifestyle" class="box" required>
                    </div>
                    <input type="submit" name="edit" class="btn" value="Save Changes">
                </form>
            </div>
        </div>

        <div class="contain" style="margin-top:50px; margin-left:700px; padding: 10px; border-radius: 20px; background-color: #ffffffc0;">
            <div class="search-container">
                <form action="" method="post" style="background-color: #ffffffc0; padding: 5px; border-radius: 10px;">
                    <input type="text" name="searchb" placeholder="Search ID..." id="searchInput">
                    <button type="submit" style="margin-bottom:100px; ">Search</button>
                </form>
            </div>

            <h1>DOCTOR'S ADVICE</h1>
            <?php
            // Display search results or all records
            if ($doctor_result->num_rows > 0) {
                echo "<table><tr>
                <th>ID</th>
                <th>Date</th>
                <th>Recommended Medicine</th>
                <th>Advice</th>
                </tr>";
                // Output data of each row
                while ($row = $doctor_result->fetch_assoc()) {
                    echo "<tr><td>" . $row["numberr"] . "</td>" . "<td>" . $row["datedoc"] . "</td>" . "<td>" . $row["recom_med"] . "</td>" . "<td>" .
                        $row["advice"] . "</td>" . "</tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            ?>
        </div>
                <br> <br> <br>
    </div>

    <!-- Custom JS for dropdown menu -->
      <script>
    document.addEventListener("DOMContentLoaded", function () {
        let subMenu = document.getElementById("subMenu");
        let modal = document.getElementById("myModal");
        let closeModal = document.querySelector(".close");
        let confirmLogout = document.getElementById("confirmLogout");
        let cancelLogout = document.getElementById("cancelLogout");

        function toggleMenu() {
            subMenu.classList.toggle("open-menu");
        }

        // Add an event listener to the user-pic element to call the toggleMenu function when clicked
        document.querySelector('.user-pic').addEventListener('click', toggleMenu);

        // Add an event listener to the logout link to show a confirmation modal
        document.getElementById('logoutLink').addEventListener('click', function (event) {
            modal.style.display = "block";
        });

        // Close the modal when the user clicks on the close button
        closeModal.addEventListener('click', function () {
            modal.style.display = "none";
        });

        // Handle logout confirmation
        confirmLogout.addEventListener('click', function () {
            window.location.href = "log.out.php"; // Redirect to logout script
        });

        // Handle cancel logout
        cancelLogout.addEventListener('click', function () {
            modal.style.display = "none"; // Close the modal
        });

        // Close the modal when the user clicks anywhere outside of it
        window.onclick = function (event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        };
    });
</script>

    <!-- JavaScript code for modal toggling and confirmation -->
    <script>
        // Get the modal
        var modal = document.getElementById('editModal');

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the edit button, open the modal
        function openModal(sub_num, symptom, duration, lifestyle) {
            document.getElementById('editSubNum').value = sub_num;
            document.getElementById('editSymptom').value = symptom;
            document.getElementById('editDuration').value = duration;
            document.getElementById('editLifestyle').value = lifestyle;
            modal.style.display = "block";
        }
        

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this record?");
        }
    </script>

</body>

</html>
