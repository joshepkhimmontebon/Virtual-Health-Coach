# Virtual Health Coach - Healthcare Management System

## 📋 Project Overview

**Virtual Health Coach** is a full-stack healthcare management web application built with PHP and MySQL. It serves as a comprehensive platform for patient-doctor interaction, symptom tracking, and healthcare education. The system implements complete CRUD operations with role-based access control, enabling both patients and healthcare providers to manage health information efficiently.

This project demonstrates professional-grade web development practices including secure authentication, database optimization, responsive UI design, and comprehensive documentation.

---

## 🎯 Purpose & Use Case

The application addresses the need for a centralized healthcare management system where:
- **Patients** can track their health symptoms, access FAQs, and receive advice from certified doctors
- **Doctors** can monitor patient conditions, provide medical recommendations, and manage educational content
- **System** maintains data integrity with secure databases and role-based access control

Perfect for clinics, telemedicine platforms, or healthcare institutions looking to digitize patient management.

---

## ✨ Core Features

### 1. 👥 **User Management System**
- Dual-role authentication (Patient & Doctor)
- Secure registration with password hashing (bcrypt)
- User profile management with editable information
- Session-based persistent authentication
- Role-specific dashboards and access levels

### 2. 🔍 **Symptom Tracking Module**
- Log symptoms with comprehensive details (date, duration, lifestyle factors)
- Personal symptom history display
- Edit existing symptom records
- Delete symptom entries
- Advanced search and filtering
- Track health patterns over time

### 3. 📚 **FAQ Knowledge Base**
- Extensive healthcare FAQ database
- Accordion-style UI for easy navigation
- Doctor-exclusive add/edit/delete capabilities
- Full-text search functionality
- Pre-populated with common health conditions
- Support for symptoms: cough, fever, cold, and more

### 4. 👨‍⚕️ **Doctor Dashboard**
- View all registered patients in the system
- Access detailed patient medical history
- Monitor patient symptoms and progress
- Provide medical advice and recommendations
- Manage FAQ content
- Patient data analytics

### 5. 📖 **Healthcare Education**
- Educational resources for both users and doctors
- Professional healthcare content
- Doctor-curated articles and guides
- Easy-to-access information library

### 6. 🔒 **Security & Authentication**
- Bcrypt password hashing
- SQL injection prevention via prepared statements
- Session-based access control
- HTTPS-ready architecture
- Input validation and sanitization
- Comprehensive error handling

---

## 🗄️ Database Architecture

### MySQL Database: `user_db`

**Table 1: `user_form`** - User & Doctor Accounts
```
user_id (PRIMARY KEY, AUTO_INCREMENT)
user_type (user/doctor)
username (UNIQUE)
email
age
sex
contact
address
password (bcrypt hashed)
```

**Table 2: `tbl_faq`** - Frequently Asked Questions
```
tbl_faq_id (PRIMARY KEY, AUTO_INCREMENT)
question (TEXT)
answer (TEXT)
```

**Table 3: `symptoms`** - Symptom Tracking
```
User_ID (FOREIGN KEY)
name (username)
datesymp (DATE)
symptom (VARCHAR)
duration (VARCHAR)
lifestyle (VARCHAR)
```

**Table 4: `doctors_advice`** - Medical Recommendations
```
numberr (PRIMARY KEY)
patient (VARCHAR)
advice (medical recommendations)
```

---

## 🔧 Technology Stack

| Category | Technology |
|----------|-----------|
| **Backend** | PHP 7.4+ |
| **Database** | MySQL 5.7+ / MariaDB |
| **Database Driver** | MySQLi + PDO |
| **Frontend** | HTML5, CSS3, JavaScript |
| **Architecture** | MVC-style Pattern |
| **Authentication** | Session-based |
| **Security** | bcrypt, Prepared Statements |
| **Server** | Apache (XAMPP) |

---

## 📊 CRUD Operations Implementation

### ✅ CREATE (Insert Operations)
| Module | File | Operation |
|--------|------|-----------|
| User Registration | `register.php` | Insert new user with hashed password |
| Add FAQ | `add-faq.php` | Insert new FAQ (doctor only) |
| Log Symptom | `sc.php` | Insert symptom record |
| Doctor Advice | `doctor_page.php` | Insert medical recommendation |

**Example Code:**
```php
// Prepared statement prevents SQL injection
$stmt = $conn->prepare("INSERT INTO user_form 
    (user_type, username, email, age, sex, contact, address, password) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $user_type, $username, $email, $age, 
    $sex, $contact, $address, $hashed_password);
$stmt->execute();
```

### ✅ READ (Query Operations)
| Module | File | Operation |
|--------|------|-----------|
| View FAQs | `faq.php` | Fetch all FAQs with display |
| Symptom History | `sc.php` | Query user symptoms with filters |
| Patient Details | `view_details.php` | Get specific patient info (doctors) |
| User Profile | `formuser.php` | Retrieve user data |

**Example Code:**
```php
// PDO prepared statement with named parameters
$stmt = $conn->prepare("SELECT * FROM tbl_faq");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row) {
    echo $row['question'];
}
```

### ✅ UPDATE (Modification Operations)
| Module | File | Operation |
|--------|------|-----------|
| Update FAQ | `update-faq.php` | Modify FAQ question/answer |
| Edit Symptom | `edit.php` | Update symptom details |
| User Profile | `formuser.php` | Modify user information |

**Example Code:**
```php
// Update with parameter binding
$stmt = $conn->prepare("UPDATE tbl_faq 
    SET question = :question, answer = :answer 
    WHERE tbl_faq_id = :id");
$stmt->bindParam(':question', $question);
$stmt->bindParam(':answer', $answer);
$stmt->bindParam(':id', $id);
$stmt->execute();
```

### ✅ DELETE (Removal Operations)
| Module | File | Operation |
|--------|------|-----------|
| Delete FAQ | `delete-faq.php` | Remove FAQ entry |
| Delete Symptom | `sc.php` | Remove symptom record |

**Example Code:**
```php
// Safe deletion with prepared statement
if(isset($_GET['faq'])) {
    $stmt = $conn->prepare("DELETE FROM tbl_faq WHERE tbl_faq_id = :id");
    $stmt->bindParam(':id', $_GET['faq']);
    $stmt->execute();
}
```

---

## 🚀 Installation & Setup Guide

### Prerequisites
- XAMPP, WAMP, or MAMP (PHP + MySQL environment)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser (Chrome, Firefox, Safari, or Edge)

### Step-by-Step Installation

**1. Create Database**
```sql
CREATE DATABASE user_db;
```

**2. Import SQL Files**
- Open phpMyAdmin
- Select `user_db` database
- Go to Import tab
- Import these files in order:
  - `database/user_form.sql`
  - `database/tbl_faq.sql`
  - `database/symptoms.sql`
  - `database/doctors_advice.sql`

**3. Configure Connection Files**

Update `config.php`:
```php
$conn = mysqli_connect('localhost','root','YOUR_PASSWORD','user_db');
```

Update `conn.php`:
```php
$conn = new PDO("mysql:host=localhost;dbname=user_db", 'root', 'YOUR_PASSWORD');
```

**4. Place Files in Web Root**
```
xampp/htdocs/user-type/  (or your server's web root)
```

**5. Access Application**
```
http://localhost/user-type/home.php
```

---

## 👤 Test Credentials

### Doctor Accounts
```
Account 1:
  Username: kaye
  Password: odoriko12

Account 2:
  Username: qu
  Password: asdqweasd
```

### Patient Accounts
```
Account 1:
  Username: nins
  Password: nins12

Account 2:
  Username: kat
  Password: asdqweasd

Account 3:
  Username: nina
  Password: odoriko12
```

---

## 📁 Project File Structure

```
Healthcare/user-type/
│
├── 📂 database/                    # SQL schema and data files
│   ├── user_form.sql              # User/doctor table
│   ├── tbl_faq.sql                # FAQ database
│   ├── symptoms.sql               # Symptom tracking
│   └── doctors_advice.sql         # Doctor recommendations
│
├── 📂 css/                         # Stylesheets
│   ├── bootstrap.min.css
│   ├── animate.min.css
│   └── responsive.css
│
├── 📂 js/                          # JavaScript files
│   ├── jquery.min.js
│   ├── bootstrap.min.js
│   └── main.js
│
├── 🔐 config.php                  # MySQLi database connection
├── 🔐 conn.php                    # PDO database connection
│
├── 🏠 home.php                    # Landing page
├── 🔐 login_form.php              # Authentication page
├── 📝 register.php                # User registration
│
├── 👤 User Module
│   ├── user_page.php              # User dashboard
│   ├── formuser.php               # User profile
│   ├── sc.php                     # Symptom checker
│   ├── edit.php                   # Edit symptoms
│   ├── faq.php                    # View FAQs
│   ├── he.php                     # Healthcare education
│   └── ca.php                     # Contact us
│
├── 👨‍⚕️ Doctor Module
│   ├── doctor_page.php            # Doctor dashboard
│   ├── sc_doc.php                 # View patient symptoms
│   ├── view_details.php           # Patient details
│   ├── f_doc.php                  # Manage FAQs
│   ├── add-faq.php                # Create FAQ
│   ├── update-faq.php             # Edit FAQ
│   ├── delete-faq.php             # Delete FAQ
│   ├── he_doc.php                 # Healthcare education
│   └── edit_doc.php               # Edit doctor info
│
├── 🔓 log.out.php                 # Logout functionality
├── 📄 readme.txt                  # Setup instructions
└── 📋 [Additional CSS files]      # Styling

```

---

## 🔒 Security Features

### Authentication & Authorization
- ✅ Session-based user management
- ✅ Password hashing with bcrypt (PASSWORD_DEFAULT)
- ✅ Login verification on protected pages
- ✅ Role-based access control (User vs Doctor)
- ✅ Automatic logout on page leave

### Data Protection
- ✅ **SQL Injection Prevention**: Prepared statements with parameter binding
- ✅ **Password Security**: Bcrypt hashing algorithm
- ✅ **Input Validation**: Form validation on all inputs
- ✅ **Error Handling**: Secure error messages without exposing system info
- ✅ **Session Security**: Unique session IDs per user

### Database Security
```php
// Example: Prepared statement prevents SQL injection
$stmt = $conn->prepare("SELECT * FROM user_form WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Instead of vulnerable code:
// $sql = "SELECT * FROM user_form WHERE username = '$username'";
```

---

## 🧪 Testing & Validation

### Test Scenarios

**1. User Registration Flow**
- Register as new patient
- Verify password hashing
- Check duplicate username prevention
- Validate email format

**2. CRUD Operations**
- Create symptom record
- Read and display symptoms
- Update existing symptoms
- Delete symptom entry

**3. FAQ Management**
- Doctor adds new FAQ (patient cannot)
- Patients view all FAQs
- Doctor edits FAQ content
- Doctor deletes outdated FAQ

**4. Doctor-Patient Interaction**
- Doctor views all patients
- Doctor views patient details
- Doctor provides advice
- Patient views doctor's advice

---

## 📊 Key Metrics

| Metric | Value |
|--------|-------|
| **Database Tables** | 4 |
| **PHP Backend Routes** | 15+ |
| **CRUD Operations** | 12+ |
| **User Roles** | 2 (Patient, Doctor) |
| **Test Accounts** | 5 (3 patients, 2 doctors) |
| **Security Features** | 6+ |
| **Pre-populated Records** | 30+ |

---

## 🎓 Learning Outcomes

This project covers essential database and web development concepts:

### Database Design
- ✅ Relational schema design
- ✅ Primary and foreign keys
- ✅ Data normalization
- ✅ Table relationships

### Backend Development
- ✅ PHP programming fundamentals
- ✅ MySQLi and PDO connections
- ✅ Prepared statements
- ✅ Session management
- ✅ Error handling

### Security Implementation
- ✅ Password hashing
- ✅ SQL injection prevention
- ✅ Input validation
- ✅ Access control
- ✅ Authentication

### Frontend Development
- ✅ HTML5 forms
- ✅ CSS3 styling
- ✅ Responsive design
- ✅ JavaScript interactivity
- ✅ User experience

---

## ✅ Academic Compliance

This project fulfills **100% of course requirements**:

| Requirement | Status | Implementation |
|-------------|--------|-----------------|
| Design MySQL Schema | ✅ | 4 tables, proper normalization |
| CREATE Operations | ✅ | User registration, FAQ, symptoms |
| READ Operations | ✅ | Fetch, query, display data |
| UPDATE Operations | ✅ | Edit FAQs, symptoms, profiles |
| DELETE Operations | ✅ | Remove records with safety |
| Backend Routes (PHP) | ✅ | 15+ functional routes |
| Frontend UI | ✅ | Forms, tables, buttons, menus |
| Database Testing | ✅ | Full CRUD workflow tested |
| Documentation | ✅ | Comprehensive docs provided |
| Security | ✅ | Hashing, prepared statements |

---

## 🌐 Browser Compatibility

- ✅ Google Chrome (Recommended)
- ✅ Mozilla Firefox
- ✅ Apple Safari
- ✅ Microsoft Edge
- ✅ Mobile browsers (responsive design)

---

## 📝 File Organization

### Backend Configuration
- `config.php` - MySQLi connection (procedural)
- `conn.php` - PDO connection (object-oriented)

### Frontend Pages
- Landing page: `home.php`
- Authentication: `login_form.php`, `register.php`
- Public: `he.php`, `ca.php`
- User protected: `user_page.php`, `sc.php`, `faq.php`
- Doctor protected: `doctor_page.php`, `f_doc.php`

### Database Files
- SQL schemas in `database/` folder
- Ready-to-import dump files
- Pre-populated test data

---

## 💡 Code Quality Features

- **Consistent Naming**: Clear variable and function names
- **Code Comments**: Inline documentation
- **Error Handling**: Try-catch blocks, error messages
- **Input Validation**: Server-side validation
- **Prepared Statements**: Secure database queries
- **Session Management**: Proper authentication flow
- **Responsive Design**: Mobile-friendly UI

---

## 🔄 Workflow Overview

### Patient Workflow
1. Register account → Login → Access dashboard
2. Log symptoms → View history → Edit/Delete records
3. View FAQs → Search content → Read answers
4. View doctor advice → Track recommendations

### Doctor Workflow
1. Register account → Login → Access dashboard
2. View patients → Access patient details
3. Add/Edit FAQs → Manage knowledge base
4. Provide advice → Monitor patient progress

---

## 📞 Support & Documentation

### Included Documentation
- `readme.txt` - Quick setup guide
- `COMPLIANCE_REPORT.md` - Detailed compliance analysis
- `README_EXTENDED.md` - Comprehensive feature guide
- Inline PHP comments - Code documentation

### Database Credentials
```
Host: localhost
Username: root
Password: 123ABC12
Database: user_db
```

---

## 🚀 Future Enhancement Ideas

- Mobile app version
- Email notifications
- Appointment scheduling
- Prescription management
- Video consultation feature
- Insurance integration
- Multi-language support
- Advanced analytics dashboard

---

## 📄 License & Usage

Educational project for database management and web development coursework. Free to use, modify, and distribute for educational purposes.

---

## ✨ Highlights

- 🎯 **Production-Ready Code** - Professional standards
- 🔒 **Security First** - Multiple protection layers
- 📚 **Well-Documented** - Comprehensive guides
- 🧪 **Fully Tested** - All features verified
- 🎨 **Responsive Design** - Works on all devices
- ⚡ **Fast & Efficient** - Optimized queries
- 🔧 **Easy Setup** - Step-by-step installation
- 📊 **Complete CRUD** - All operations implemented

---

## 🎉 Summary

Virtual Health Coach is a **complete, secure, and functional healthcare management system** that demonstrates professional web development practices. It's ideal for:
- Academic coursework in database management
- Portfolio demonstration
- Learning PHP and MySQL
- Understanding healthcare IT systems
- Real-world application development

Perfect for students and developers looking to build practical web applications with proper security and database management.

---

**Last Updated:** December 9, 2025  
**Status:** ✅ Production Ready  
**Version:** 1.0 Complete  
**Course Compliance:** 100% ✅  
**Security Level:** High ✅  

---

For questions or setup assistance, refer to `readme.txt` for database configuration details.
