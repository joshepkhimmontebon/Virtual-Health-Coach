<?php
include 'config.php'; // Ensure this file contains the database connection code
session_start();

if(isset($_POST['submit'])){
    $user_type = mysqli_real_escape_string($conn, $_POST['user_type']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $age = mysqli_real_escape_string($conn, $_POST['age']);
    $sex = mysqli_real_escape_string($conn, $_POST['sex']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    
    // Hash the password securely using bcrypt
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if the passwords match
    if($password != $cpassword){
        $message = 'Passwords do not match!';
    } else {
        // Use prepared statements to prevent SQL injection
        $select = $conn->prepare("SELECT * FROM `user_form` WHERE username = ?");
        $select->bind_param("s", $username);
        $select->execute();
        $result = $select->get_result();

        if($result->num_rows > 0){
            $message = 'User already exists!';
        } else {
            // Insert user data into the database
            $insert = $conn->prepare("INSERT INTO `user_form` (user_type, username, email, age, sex, contact, address, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->bind_param("ssssssss", $user_type, $username, $email, $age, $sex, $contact, $address, $hashed_password);
            $insert->execute();

            if($insert){
                // Get the auto-generated user ID
                $user_id = mysqli_insert_id($conn);
                
                // Store the user ID in session or display it as needed
                $_SESSION['user_id'] = $user_id;
                
                $_SESSION['message'] = 'Registered successfully!';
                header('Location: login_form.php');
                exit();
            } else {
                $message = 'Registration failed!';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>  
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form</title>
    <link rel="stylesheet" href="s.css"> <!-- Ensure this file exists -->
</head>
<body>
    <div class="form-container" id="contain">
        <form action="" method="post" enctype="multipart/form-data">
            <h2>Register Now</h2>
            <?php if(isset($message)): ?>
                <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>
            <select name="user_type">
                <option value="user">User</option>
                <option value="doctor">Doctor</option>
            </select>
            <input type="text" name="username" placeholder="Enter username" class="box" required>
            <input type="email" name="email" placeholder="Enter Email" class="box" required>
            <input type="text" name="age" placeholder="Enter Age" class="box" required>
            <input type="text" name="sex" placeholder="Enter Sex" class="box" required>
            <input type="text" name="contact" placeholder="Enter Contact" class="box" required>
            <input type="text" name="address" placeholder="Enter Address" class="box" required>
            <input type="password" name="password" placeholder="Enter password" class="box" required>
            <input type="password" name="cpassword" placeholder="Confirm password" class="box" required>
            <input type="submit" name="submit" value="Register now" class="btn">
            <p>Already have an account? <a href="login_form.php">Login now</a></p>
        </form>
    </div>
</body>
</html>
